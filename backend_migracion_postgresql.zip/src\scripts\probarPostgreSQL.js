import "dotenv/config";
import {
  connectPostgreSQL,
  disconnectPostgreSQL,
} from "../config/postgresql.js";

try {
  const estado = await connectPostgreSQL();

  console.log("Conexión PostgreSQL correcta.");
  console.log({
    baseDeDatos: estado?.database,
    usuario: estado?.usuario,
  });

  process.exitCode = 0;
} catch (error) {
  console.error("No fue posible conectar con PostgreSQL.");
  console.error(error?.message || error);
  process.exitCode = 1;
} finally {
  await disconnectPostgreSQL();
}
