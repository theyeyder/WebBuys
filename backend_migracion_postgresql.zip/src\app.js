import express from "express";

import cors from "cors";

import morgan from "morgan";

import path from "path";

import authRoutes from "./routes/auth.routes.js";

import usuarioRoutes from "./routes/usuario.routes.js";

import configuracionRoutes from "./routes/configuracion.routes.js";

import rutaRoutes from "./routes/ruta.routes.js";

import zonaDespachoRoutes from "./routes/zonaDespacho.routes.js";

import clienteRoutes from "./routes/cliente.routes.js";

import numeracionRoutes from "./routes/numeracion.routes.js";

import preferenciaRoutes from "./routes/preferencia.routes.js";

import auditoriaRoutes from "./routes/auditoria.routes.js";

import categoriaRoutes from "./routes/categoria.routes.js";

import productoRoutes from "./routes/producto.routes.js";

import inventarioRoutes from "./routes/inventario.routes.js";

import pedidoRoutes from "./routes/pedido.routes.js";

import entregaRoutes from "./routes/entrega.routes.js";

import empleadoRoutes from "./routes/empleado.routes.js";

import facturaRoutes from "./routes/factura.routes.js";

import cajaRoutes from "./routes/caja.routes.js";

import carteraRoutes from "./routes/cartera.routes.js";


const app = express();


/* =========================================
   MIDDLEWARES
========================================= */

app.use(
  cors()
);

app.use(
  express.json()
);

app.use(
  "/uploads",
  express.static(
    path.resolve(
      "uploads"
    )
  )
);

app.use(
  morgan(
    "dev"
  )
);


/* =========================================
   RUTA PRINCIPAL
========================================= */

app.get(
  "/",
  (_, res) =>

    res.json({
      app: "WebBuys API",
      status: "OK",
    })
);


/* =========================================
   RUTAS API
========================================= */

app.use(
  "/api/auth",
  authRoutes
);

app.use(
  "/api/usuarios",
  usuarioRoutes
);

app.use(
  "/api/configuracion",
  configuracionRoutes
);

app.use(
  "/api/rutas",
  rutaRoutes
);

app.use(
  "/api/zonas-despacho",
  zonaDespachoRoutes
);

app.use(
  "/api/clientes",
  clienteRoutes
);

app.use(
  "/api/numeracion",
  numeracionRoutes
);

app.use(
  "/api/preferencias",
  preferenciaRoutes
);

app.use(
  "/api/auditoria",
  auditoriaRoutes
);

app.use(
  "/api/categorias",
  categoriaRoutes
);

app.use(
  "/api/productos",
  productoRoutes
);

app.use(
  "/api/inventario",
  inventarioRoutes
);

app.use(
  "/api/pedidos",
  pedidoRoutes
);

app.use(
  "/api/entregas",
  entregaRoutes
);

app.use(
  "/api/empleados",
  empleadoRoutes
);

app.use(
  "/api/facturas",
  facturaRoutes
);

app.use(
  "/api/caja",
  cajaRoutes
);


app.use(
  "/api/cartera",
  carteraRoutes
);


export default app;
